// Learn more about Tauri commands at https://tauri.app/develop/calling-rust/
#[tauri::command]
fn greet(name: &str) -> String {
    format!("Hello, {}! You've been greeted from Rust!", name)
}

#[tauri::command]
fn test_command() -> String {
    "Test works!".to_string()
}

pub mod media_player;
pub mod playlist;

use tauri::Manager;

// Re-export the commands
pub use media_player::{check_file_exists, get_audio_metadata, update_metadata};

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_global_shortcut::Builder::new().build())
        .plugin(tauri_plugin_opener::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_shell::init())
        .setup(|app| {
            use std::sync::Mutex;
            use tauri_plugin_shell::ShellExt;

            // Launch the discord-bridge sidecar automatically
            let sidecar_command = app.shell().sidecar("discord-bridge");
            match sidecar_command {
                Ok(cmd) => {
                    match cmd.spawn() {
                        Ok(child) => {
                            // Store the child process so we can kill it later
                            app.manage(Mutex::new(Some(child)));
                            println!("✅ Sidecar: Discord Presence Bridge started.");
                        }
                        Err(e) => {
                            println!("❌ Sidecar: Failed to spawn: {}", e);
                        }
                    }
                }
                Err(e) => {
                    println!("❌ Sidecar: Failed to create command: {}", e);
                }
            }
            Ok(())
        })
        .on_window_event(|window, event| {
            use std::sync::Mutex;
            use tauri::WindowEvent;
            use tauri_plugin_shell::process::CommandChild;

            if let WindowEvent::Destroyed = event {
                // Kill the sidecar when the window closes
                if let Some(state) = window.try_state::<Mutex<Option<CommandChild>>>() {
                    if let Ok(mut guard) = state.try_lock() {
                        if let Some(child) = guard.take() {
                            let _ = child.kill();
                            println!("🛑 Sidecar: Discord bridge terminated.");
                        }
                    }
                }
            }
        })
        .invoke_handler(tauri::generate_handler![
            greet,
            test_command,
            get_audio_metadata,
            media_player::get_audio_file_info,
            update_metadata,
            check_file_exists,
            playlist::save_playlist,
            playlist::load_playlist,
            playlist::get_playlists,
            playlist::delete_playlist,
            playlist::rename_playlist,
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
